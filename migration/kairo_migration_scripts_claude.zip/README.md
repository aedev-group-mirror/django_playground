# Django + django-cms Migration Scripts

Automated migration toolkit for the **kairos** project  
(`gitlab.com/ae-group/kairos`)

**From:** Django 3.1 · django-cms 3.8  
**To:**   Django 5.2 (LTS) · django-cms 5.x

---

## Migration Path

```
Django 3.1 / CMS 3.8
      │
      ▼  step1_django32.py
Django 3.2 / CMS 3.11  (last stable 3.x CMS)
      │
      ▼  step2_django42.py
Django 4.2 (LTS) / CMS 3.11
      │
      ▼  step3_django52.py
Django 5.2 (LTS) / CMS 3.11
      │
      ▼  step4_cms4.py          ← MAJOR CHANGE (see note)
Django 5.2 / CMS 4.1
      │
      ▼  step5_cms5.py
Django 5.2 / CMS 5.x  ✓ TARGET
```

> **Note on Django 6.0**: As of early 2026, Django 6.0 is not yet released.
> The scripts target **Django 5.2 LTS** (released April 2025).
> Once Django 6.0 is released and supported by the CMS ecosystem,
> bump `Django==6.0` in `requirements.txt` and re-run `step3_django52.py`
> to pick up any new deprecations.

---

## Prerequisites

### 1. Backups (mandatory before each step)

```bash
# Full database backup
cp project.db project.db.MASTER_BACKUP

# Full media files backup
tar -czf media_backup_$(date +%Y%m%d).tar.gz media/

# Commit current state to git
git add -A && git commit -m "pre-migration snapshot"
```

### 2. Python version

| Migration step | Minimum Python |
|----------------|---------------|
| Steps 1–2      | 3.8            |
| Steps 3–5      | **3.10** (Django 4.2+ requires 3.10) |

Check your Python: `python --version`

Upgrade if needed (e.g. via pyenv):
```bash
pyenv install 3.12.3
pyenv local 3.12.3
```

### 3. Virtual environment

Always work inside a virtual environment:
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install --upgrade pip
pip install -r requirements.txt
```

---

## Quickstart

### Step 0 — Pre-flight analysis (run this first!)

```bash
python migration_scripts/preflight_check.py --project-root .
```

This produces `migration_preflight_report.md` with:
- All deprecated API usages grouped by which migration step fixes them
- Effort estimates per step
- CMS configuration issues

---

### Step 1 — Django 3.2 + CMS 3.11

```bash
python migration_scripts/step1_django32.py \
  --project-root . \
  --db project.db
```

**What it does:**
- Updates `requirements.txt` to Django 3.2 and CMS 3.11
- Replaces all `ugettext`/`ugettext_lazy` → `gettext`/`gettext_lazy`
- Replaces `url()` calls with `re_path()`
- Adds `DEFAULT_AUTO_FIELD` setting
- Runs `python manage.py migrate`

**Manual follow-up:**
- Check for `apphook_pool.register(` calls → convert to decorator form
- Review middleware ordering in settings

---

### Step 2 — Django 4.2 LTS

```bash
python migration_scripts/step2_django42.py \
  --project-root . \
  --db project.db
```

**What it does:**
- Updates to Django 4.2
- Adds `https://` scheme to `CSRF_TRUSTED_ORIGINS` entries
- Removes `USE_DEPRECATED_PYTZ = True`
- Replaces `force_text` → `force_str`, `smart_text` → `smart_str`
- Replaces `request.is_ajax()` → `request.headers.get(...)` check
- Replaces `render_to_response` → `render`
- Adds `crispy-bootstrap4` split package
- Patches `CRISPY_TEMPLATE_PACK` setting
- Fixes `{% load staticfiles %}` → `{% load static %}` in templates

**Manual follow-up:**
- Set `PASSWORD_RESET_TIMEOUT` in seconds (replaces `PASSWORD_RESET_TIMEOUT_DAYS`)
- Verify `CSRF_TRUSTED_ORIGINS` values are correct for your domain(s)

---

### Step 3 — Django 5.2 LTS

```bash
python migration_scripts/step3_django52.py \
  --project-root . \
  --db project.db
```

**What it does:**
- Updates to Django 5.2
- Removes `pytz` (replaced by `stdlib zoneinfo`)
- Replaces `pytz.timezone(...)` → `ZoneInfo(...)`
- Removes `USE_DEPRECATED_PYTZ` setting (hard-removed in Django 5.0)
- Removes `BrokenLinkEmailsMiddleware`
- Ensures `SITE_ID` is set

**Manual follow-up:**
- Fix any `unique_together` → `UniqueConstraint` (see warnings in output)
- Fix any `index_together` → `Meta.indexes = [Index(...)]`
- Review timezone handling in models/views that relied on pytz

---

### Step 4 — django-cms 4.x  ⚠ MAJOR

This is the most complex step. **Allow 4–8 hours minimum.**

```bash
python migration_scripts/step4_cms4.py \
  --project-root . \
  --db project.db
```

**What it does:**
- Upgrades CMS from 3.11 → 4.1
- Installs `djangocms-versioning` (new required dependency)
- Replaces `djangocms-text-ckeditor` → `djangocms-text`
- Renames `{% static_placeholder %}` → `{% page_placeholder %}` in templates
- Runs `python manage.py migrate` + `cms fix-tree`
- Produces `cms4_page_attribute_review.txt` (manual review required)
- Produces `cms4_bootstrap4_migration.txt` (choose migration strategy)

**The CMS 4 architectural change in plain English:**

In CMS 3, a `Page` object held both the tree structure and all language
content (via the `Title` model). In CMS 4:

- `Page` = just the tree node (structure, no content)
- `PageContent` = the language-specific content (title, slug, template…)
- All content is now "versioned" by `djangocms-versioning`
- The old "draft/live" toggle is gone; publishing is done through versioning

**Code changes required (manual):**

| Old (CMS 3)                   | New (CMS 4)                             |
|-------------------------------|-----------------------------------------|
| `page.title`                  | `page.get_content_obj().title`          |
| `page.slug`                   | `page.get_content_obj().slug`           |
| `page.get_title()`            | `page.get_content_obj().title`          |
| `page.get_slug()`             | `page.get_content_obj().slug`           |
| `Page.objects.drafts()`       | Use versioning API                      |
| `Page.objects.public()`       | Use versioning API                      |
| `cms.models.Title`            | `cms.models.PageContent`                |

**INSTALLED_APPS changes (manual edit in settings.py):**

```python
# REMOVE these:
'djangocms_text_ckeditor',
'djangocms_bootstrap4',

# ADD these (versioning BEFORE cms):
'djangocms_versioning',
'djangocms_text',
```

**Bootstrap4 plugin migration:**

`djangocms-bootstrap4` is incompatible with CMS 4. You have three options:

**Option A** — Migrate to djangocms-bootstrap5:
```bash
pip install djangocms-bootstrap5
# Add 'djangocms_bootstrap5' to INSTALLED_APPS
# Run their provided data migration
```

**Option B** — Convert to plain HTML (most control):
- Export page content via CMS admin
- Replace Bootstrap4 plugin blocks with Text plugin HTML snippets
- Tedious but future-proof

**Option C** — Keep old data frozen:
- Remove from INSTALLED_APPS but keep DB tables
- Render via a custom template tag that reads old plugin data

---

### Step 5 — django-cms 5.x

```bash
python migration_scripts/step5_cms5.py \
  --project-root . \
  --db project.db
```

**What it does:**
- Upgrades CMS 4.1 → 5.x
- Updates all djangocms-* plugins to CMS-5-compatible versions
- Removes `CMS_CONFIRM_VERSION_4` setting
- Checks for sideframe usage (removed in CMS 5)
- Checks apphook namespace uniqueness
- Generates `CMS5_MIGRATION_CHECKLIST.md`

---

## Command-line flags

All step scripts support these flags:

| Flag | Description |
|------|-------------|
| `--project-root DIR` | Project directory (contains manage.py). Default: `.` |
| `--requirements FILE` | Path to requirements.txt. Default: `requirements.txt` |
| `--settings a.py,b.py` | Comma-separated settings files to patch |
| `--db FILE` | SQLite database filename. Default: `project.db` |
| `--skip-install` | Don't run `pip install` (apply code patches only) |
| `--skip-migrate` | Don't run `manage.py migrate` |

---

## Package version reference

| Package | Start | After Step 1 | After Step 2 | After Step 3 | After Step 4 | After Step 5 |
|---|---|---|---|---|---|---|
| Django | 3.1.14 | **3.2.25** | **4.2.17** | **5.2** | 5.2 | 5.2 |
| django-cms | 3.8.0 | **3.11.8** | 3.11.8 | 3.11.8 | **4.1.3** | **5.0.3** |
| djangocms-versioning | — | — | — | — | **2.1.0** | **2.3.0** |
| djangocms-text-ckeditor | 4.0.0 | 4.1.0 | 4.1.1 | 4.2.0 | **removed** | — |
| djangocms-text | — | — | — | — | **0.6.0** | **0.8.0** |
| djangocms-bootstrap4 | 2.0.0 | 2.0.0 | 2.0.0 | 2.0.0 | **removed\*** | — |
| django-filer | 2.2.4 | 3.0.4 | 3.1.2 | 3.3.1 | 3.3.1 | 3.3.1 |
| easy-thumbnails | 2.8.5 | 2.8.5 | 2.9.0 | **2.10.0** | 2.10.0 | 2.10.0 |
| django-crispy-forms | 1.14.0 | 1.14.0 | **2.3** | 2.3 | 2.3 | 2.3 |
| crispy-bootstrap4 | — | — | **2024.1** | 2024.1 | 2024.1 | 2024.1 |
| django-sekizai | 3.0.1 | 3.0.1 | 4.0.0 | 4.1.0 | 4.1.0 | 4.1.0 |
| django-treebeard | 4.4 | **4.7.1** | 4.7.1 | 4.7.1 | 4.7.1 | 4.7.1 |

\* Requires Bootstrap migration — see Step 4 notes.

---

## Troubleshooting

### `ImportError: cannot import name 'ugettext_lazy' from 'django.utils.translation'`
Run step 1 first. This import was removed in Django 4.0.

### `django.db.utils.OperationalError: no such table: cms_pagecontent`
The CMS 4 data migration hasn't run yet.
```bash
python manage.py migrate
python manage.py cms fix-tree
```

### `CSRF verification failed` after Django 4.0 upgrade
Your `CSRF_TRUSTED_ORIGINS` entries need `https://` prefix.
```python
CSRF_TRUSTED_ORIGINS = ['https://yourdomain.com']  # not just 'yourdomain.com'
```

### `ValueError: Missing staticfiles manifest entry for 'cms/...`
Run collectstatic after each major upgrade:
```bash
python manage.py collectstatic --noinput
```

### Versioning errors / `Version matching query does not exist`
CMS 4+ requires all PageContent to have a Version record.
```bash
python manage.py versioning_create_initial_versions
```

### `RuntimeError: Database returned a bad value` on SQLite with pytz
Remove `pytz` from requirements after Step 3 and ensure `USE_TZ = True`
and `TIME_ZONE = 'UTC'` (or your local timezone as a string).

---

## Static files after migration

After completing all steps, regenerate static files:

```bash
python manage.py collectstatic --noinput --clear
```

If you use `ManifestStaticFilesStorage`, delete the old manifest first:
```bash
rm staticfiles/staticfiles.json  # or wherever STATIC_ROOT points
python manage.py collectstatic --noinput
```

---

## Database migration for PostgreSQL (if applicable)

These scripts are written for the project's SQLite database.
If you later migrate to PostgreSQL:

```bash
pip install psycopg2-binary
# Install pgloader:
pgloader project.db postgresql://user:pass@localhost/kairos_db
```

Then update `DATABASES` in settings.py accordingly.

---

## Files produced by the scripts

| File | Produced by | Purpose |
|------|-------------|---------|
| `migration_preflight_report.md` | `preflight_check.py` | Full analysis before starting |
| `*.bak` (requirements, settings) | All steps | Backup of modified files |
| `project.db_pre_step*.bak` | All steps | DB snapshot before each step |
| `cms4_page_attribute_review.txt` | Step 4 | Lines needing manual Page→PageContent fix |
| `cms4_bootstrap4_migration.txt` | Step 4 | Bootstrap4 migration strategy guide |
| `CMS5_MIGRATION_CHECKLIST.md` | Step 5 | Final go-live checklist |
